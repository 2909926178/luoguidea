#include<bits/stdc++.h>
using namespace std;
int main()
{
	int a,b,c,d,e,maxx,minn;
	cin>>a>>b>>c>>d>>e;
	int dcz=(-2*a)/b;
	if(d<=dcz&&dcz<=e)
	{
		if(a>0) 
		{
			minn=(4*a*c-b*b)/(4*a);
			if(abs(d-dcz)>=abs(e-dcz)) maxx=a*d*d+b*d+c;
			else maxx=a*e*e+b*e+c;
		}
		else if(a<0) 
		{
			maxx=(4*a*c-b*b)/(4*a);
			if(abs(d-dcz)>=abs(e-dcz)) minn=a*d*d+b*d+c;
			else minn=a*e*e+b*e+c;
		}
	}
	else if(d>dcz||dcz>e)
	{
		if(a>0)
		{
			if(abs(d-dcz)>=abs(e-dcz))
			{
				maxx=a*d*d+b*d+c;
				minn=a*e*e+b*e+c;
			}
			else
			{
				minn=a*d*d+b*d+c;
				maxx=a*e*e+b*e+c;
			}
	    }
		if(a<0)
		{
			if(abs(d-dcz)>=abs(e-dcz))
			{
			minn=a*d*d+b*d+c;	
			maxx=a*e*e+b*e+c;
			}
			else
			{
				maxx=a*d*d+b*d+c;
				minn=a*e*e+b*e+c;
			}
		}
	}
	cout<<maxx<<' '<<minn;
	return 0;
}