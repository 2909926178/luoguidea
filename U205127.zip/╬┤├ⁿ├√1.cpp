#include<bits/stdc++.h>
using namespace std;
bool cmp(int a,int b)
{
	return a>b;
}
int main(){
	int n;
	int maxx=0;
	int a[10001],b[10001]={0};
	double sum=0.00,mid=0.00,flag=0.00;
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i];
		sum+=a[i];
		b[a[i]]++;
	}
	sort(a+1,a+n+1);
	cout<<fixed<<setprecision(2)<<sum/n<<' ';
	if(n%2==1) mid=a[(n+1)/2];
	else mid=(a[n/2]+a[n/2+1])/2;
	cout<<fixed<<setprecision(2)<<mid<<' ';
    for(int i=1;i<=10000;i++)
    {
    	if(maxx<=b[i])
    	maxx=b[i];
	}
    for(int i=1;i<=10009;i++)
    {
    	if(maxx==b[i])
    	{
    		flag=i;
    		break;
		}
	}
	cout<<fixed<<setprecision(2)<<flag;
	return 0;
}
